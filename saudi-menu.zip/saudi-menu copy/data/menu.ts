export const menuData = {
  storeName: "Al-Majlis Cafe | المجلس",
  whatsapp: "966500657031", // Replace with owner's number
  categories: [
    {
      id: 1,
      nameAr: "القهوة المختصة",
      nameEn: "Specialty Coffee",
      items: [
        { id: 101, nameAr: "فلات وايت", nameEn: "Flat White", price: 18, image: "/flat-white.jpg" },
        { id: 102, nameAr: "سبانش لاتيه", nameEn: "Spanish Latte", price: 22, image: "/spanish.jpg" },
      ]
    }
  ]
};