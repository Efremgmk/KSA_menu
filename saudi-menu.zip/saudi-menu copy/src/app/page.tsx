"use client";
import React, { useState } from 'react';
import { ShoppingCart, Send, Plus, Minus } from 'lucide-react';
import { menuData } from '../../data/menu';

type CartItem = {
  id: string | number;
  nameAr: string;
  nameEn: string;
  price: number;
  qty: number;
};

type MenuItem = Omit<CartItem, 'qty'>;

export default function MenuPage() {
  const [cart, setCart] = useState<CartItem[]>([]);

  const addToCart = (item: MenuItem) => {
    const existing = cart.find(i => i.id === item.id);
    if (existing) {
      setCart(cart.map(i => i.id === item.id ? { ...i, qty: i.qty + 1 } : i));
    } else {
      setCart([...cart, { ...item, qty: 1 }]);
    }
  };

  const sendWhatsApp = () => {
    const itemsList = cart.map(i => `• ${i.qty}x ${i.nameAr} / ${i.nameEn}`).join('\n');
    const total = cart.reduce((acc, i) => acc + (i.price * i.qty), 0);
    const text = encodeURIComponent(`📥 *طلب جديد*\n\n${itemsList}\n\n💰 *المجموع:* ${total} ريال`);
    window.open(`https://wa.me/${menuData.whatsapp}?text=${text}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-white font-sans pb-24" dir="rtl">
      {/* Header */}
      <header className="p-6 text-center border-b border-yellow-600/30">
        <h1 className="text-2xl font-bold text-yellow-500">{menuData.storeName}</h1>
        <p className="text-neutral-400 text-sm">أهلاً بكم في منطقتنا / Welcome</p>
      </header>

      {/* Menu Sections */}
      <main className="p-4 max-w-md mx-auto">
        {menuData.categories.map(cat => (
          <div key={cat.id} className="mb-8">
            <h2 className="text-xl font-bold border-r-4 border-yellow-500 pr-3 mb-4">{cat.nameAr}</h2>
            <div className="space-y-4">
              {cat.items.map(item => (
                <div key={item.id} className="bg-neutral-900 p-4 rounded-xl flex justify-between items-center border border-neutral-800">
                  <div>
                    <h3 className="font-bold">{item.nameAr}</h3>
                    <p className="text-xs text-neutral-500">{item.nameEn}</p>
                    <p className="text-yellow-500 font-bold mt-1">{item.price} SAR</p>
                  </div>
                  <button 
                    onClick={() => addToCart(item)}
                    className="bg-yellow-600 hover:bg-yellow-500 p-2 rounded-full transition"
                  >
                    <Plus size={20} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ))}
      </main>

      {/* Floating Cart Button */}
      {cart.length > 0 && (
        <div className="fixed bottom-6 inset-x-0 px-4">
          <button 
            onClick={sendWhatsApp}
            className="w-full max-w-md mx-auto bg-green-600 hover:bg-green-500 text-white py-4 rounded-2xl flex justify-center items-center gap-3 shadow-2xl shadow-green-900/20 font-bold"
          >
            <Send size={20} />
            إرسال الطلب عبر الواتساب ({cart.reduce((acc, i) => acc + i.qty, 0)})
          </button>
        </div>
      )}
    </div>
  );
}